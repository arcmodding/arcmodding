const USER_ID = 2612060275;
const GROUP_ID = 11231713;
const headers = {"User-Agent": "NOSTYLISTT-Website/1.0"};

async function getJson(url) {
  const response = await fetch(url, {headers});
  if (!response.ok) throw new Error(`Upstream ${response.status}`);
  return response.json();
}

export async function onRequestGet({request}) {
  const origin = new URL(request.url).origin;
  const results = await Promise.allSettled([
    getJson(`https://users.roblox.com/v1/users/${USER_ID}`),
    getJson(`https://groups.roblox.com/v1/groups/${GROUP_ID}`),
    getJson(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${USER_ID}&size=420x420&format=Png&isCircular=false`),
    getJson(`https://thumbnails.roblox.com/v1/groups/icons?groupIds=${GROUP_ID}&size=420x420&format=Png&isCircular=false`)
  ]);
  const user = results[0].status === "fulfilled" ? results[0].value : null;
  const group = results[1].status === "fulfilled" ? results[1].value : null;
  const thumbs = results[2].status === "fulfilled" ? results[2].value : null;
  const avatar = thumbs?.data?.[0]?.imageUrl || null;
  const groupThumbs = results[3].status === "fulfilled" ? results[3].value : null;
  const groupIcon = groupThumbs?.data?.[0]?.imageUrl || null;
  const payload = {
    user: user ? {id: user.id, name: user.name, displayName: user.displayName, description: user.description} : null,
    group: group ? {
      id: group.id, name: group.name, description: group.description,
      memberCount: group.memberCount,
      owner: group.owner ? {id: group.owner.userId, username: group.owner.username, displayName: group.owner.displayName} : null
    } : null,
    avatar,
    groupIcon,
    partial: results.some(result => result.status === "rejected")
  };
  return new Response(JSON.stringify(payload), {
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "public, max-age=300, s-maxage=300",
      "access-control-allow-origin": origin
    }
  });
}
