# NOSTYLISTT — GitHub + Cloudflare Pages

A static, responsive NOSTYLISTT development-group website with seven interactive sections and a Cloudflare Pages Function for public Roblox profile/group data.

## Upload this project to GitHub

1. Download and extract `NOSTYLISTT-GitHub-Ready.zip` on your computer.
2. Go to https://github.com/new and create a repository named `nostylistt-website`.
3. Choose **Public** or **Private**, then create the repository.
4. In the empty repository, choose **Add file → Upload files**.
5. Open the extracted project folder and select **all files and folders inside it**. Upload the contents, not the ZIP file itself.
6. Make sure `index.html`, `styles.css`, `script.js`, `assets/`, and `functions/` are at the repository root.
7. Enter a commit message such as `Upload NOSTYLISTT website` and click **Commit changes**.

Expected repository layout:

```text
nostylistt-website/
├── index.html
├── styles.css
├── script.js
├── README.md
├── .gitignore
├── assets/
│   └── nostylistt-logo.jpg
└── functions/
    └── api/
        └── roblox.js
```

## Connect GitHub to Cloudflare Pages

1. Open Cloudflare Dashboard → **Workers & Pages**.
2. Choose **Create application** → **Pages** → **Connect to Git**.
3. Authorize GitHub if prompted, then select `nostylistt-website`.
4. Set:
   - Framework preset: **None**
   - Production branch: `main`
   - Build command: leave blank
   - Build output directory: `.`
5. Click **Save and Deploy**.

Keep the `functions/` directory at the project root. Cloudflare Pages uses `functions/api/roblox.js` to provide the `/api/roblox` endpoint. Git integration is recommended so the Pages Function is deployed with the site.

## Website sections

- Home
- About
- Creator — dedicated Tech biography
- Development
- Projects
- Community
- Contact

## Official Roblox pages

- Creator: https://www.roblox.com/users/2612060275/profile
- NOSTYLISTT group: https://www.roblox.com/communities/11231713/NOSTYLISTT
- Featured LARP CATALOG experience: https://www.roblox.com/games/90886486704408/LARP-CATALOG

The profile and group metrics displayed in the biography are based on the screenshots supplied for this website. Live public Roblox API values may change or be temporarily unavailable.

## Customize the site

- Edit text and page structure in `index.html`.
- Edit colors, layout, and animation styling in `styles.css`.
- Edit interactions in `script.js`.
- Replace `assets/nostylistt-logo.jpg` to change the official logo.
- Roblox IDs are configured in `functions/api/roblox.js` and referenced in the page markup.

No framework, npm install, or build command is required.
