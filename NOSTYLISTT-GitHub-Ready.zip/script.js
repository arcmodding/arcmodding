const nav = document.querySelector(".desktop-nav");
const menuToggle = document.querySelector(".menu-toggle");
const pages = [...document.querySelectorAll(".page")];
const navLinks = [...document.querySelectorAll(".nav-link")];
const toast = document.querySelector(".toast");

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 2100);
}
function activateTab(tab) {
  if (!pages.some(page => page.dataset.page === tab)) return;
  pages.forEach(page => page.classList.toggle("active", page.dataset.page === tab));
  navLinks.forEach(link => link.classList.toggle("active", link.dataset.tab === tab));
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
  window.scrollTo({top: 0, behavior: "smooth"});
  history.replaceState(null, "", `#${tab}`);
}
navLinks.forEach(link => link.addEventListener("click", () => activateTab(link.dataset.tab)));
document.querySelectorAll("[data-go]").forEach(button => button.addEventListener("click", () => activateTab(button.dataset.go)));
document.querySelectorAll("[data-scroll-to]").forEach(button => button.addEventListener("click", () => {
  document.getElementById(button.dataset.scrollTo)?.scrollIntoView({behavior:"smooth",block:"start"});
}));
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
});
document.querySelectorAll("[data-copy]").forEach(button => button.addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(button.dataset.copy); showToast("Copied to clipboard"); }
  catch { showToast(`ID: ${button.dataset.copy}`); }
}));
document.getElementById("year").textContent = new Date().getFullYear();
const initial = location.hash.slice(1);
if (initial && pages.some(page => page.dataset.page === initial)) activateTab(initial);

async function loadRobloxData() {
  const status = document.getElementById("api-status");
  try {
    const response = await fetch("/api/roblox", {headers: {"Accept": "application/json"}});
    if (!response.ok) throw new Error("Roblox API unavailable");
    const data = await response.json();
    if (data.user?.name) document.getElementById("creator-name").textContent = data.user.displayName || data.user.name;
    if (data.user?.name) document.getElementById("creator-handle").textContent = `@${data.user.name} · User ID: 2612060275`;
    if (data.avatar) document.getElementById("avatar").src = data.avatar;
    if (data.group?.name) document.getElementById("group-name").textContent = data.group.name;
    if (data.group?.description) document.getElementById("group-description").textContent = data.group.description;
    if (Number.isFinite(data.group?.memberCount)) document.getElementById("member-count").textContent = data.group.memberCount.toLocaleString();
    if (data.group?.owner?.username) document.getElementById("group-owner").textContent = data.group.owner.displayName || data.group.owner.username;
    if (data.groupIcon) document.getElementById("group-icon").src = data.groupIcon;
    status.textContent = data.partial ? "Some public Roblox fields are temporarily unavailable." : "Public Roblox profile and community data loaded.";
  } catch (error) {
    status.textContent = "Live data unavailable right now — official Roblox links remain available.";
    document.getElementById("creator-name").textContent = "Tech";
    document.getElementById("creator-handle").textContent = "@cxrsetdimess · User ID: 2612060275";
    document.getElementById("member-count").textContent = "3,598";
  }
}
loadRobloxData();


// Pointer-following light and scroll progress.
const glow = document.querySelector(".cursor-glow");
const progressBar = document.querySelector(".scroll-progress span");
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
window.addEventListener("pointermove", event => {
  if (glow) {
    glow.style.left = `${event.clientX}px`;
    glow.style.top = `${event.clientY}px`;
    document.body.classList.add("pointer-active");
  }
}, {passive:true});
window.addEventListener("pointerleave", () => document.body.classList.remove("pointer-active"));
function updateProgress() {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  const pct = max > 0 ? (window.scrollY / max) * 100 : 0;
  if (progressBar) progressBar.style.width = `${pct}%`;
}
window.addEventListener("scroll", updateProgress, {passive:true});
updateProgress();

// Tilt surfaces: subtle perspective follows the pointer, with a clean reset.
if (!reduceMotion) {
  document.querySelectorAll(".feature-card,.skill-card,.contact-card,.project-card").forEach(card => {
    card.addEventListener("pointermove", event => {
      if (event.pointerType === "touch") return;
      const rect = card.getBoundingClientRect();
      const x = (event.clientX - rect.left) / rect.width;
      const y = (event.clientY - rect.top) / rect.height;
      card.style.setProperty("--mx", `${x * 100}%`);
      card.style.setProperty("--my", `${y * 100}%`);
      const rx = (0.5 - y) * 4;
      const ry = (x - 0.5) * 5;
      card.style.transform = `perspective(900px) rotateX(${rx}deg) rotateY(${ry}deg) translateY(-3px)`;
    });
    card.addEventListener("pointerleave", () => {
      card.style.transform = "";
      card.style.removeProperty("--mx");
      card.style.removeProperty("--my");
    });
  });

  const heroArt = document.querySelector(".hero-art");
  if (heroArt) {
    heroArt.addEventListener("pointermove", event => {
      const r = heroArt.getBoundingClientRect();
      const x = (event.clientX - r.left) / r.width - .5;
      const y = (event.clientY - r.top) / r.height - .5;
      heroArt.style.transform = `perspective(1000px) rotateY(${x * 5}deg) rotateX(${-y * 5}deg)`;
    });
    heroArt.addEventListener("pointerleave", () => heroArt.style.transform = "");
  }
}

// Animated particle field in the hero visual. No external libraries required.
(() => {
  const canvas = document.querySelector(".particle-canvas");
  if (!canvas || reduceMotion) return;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;
  let width = 0, height = 0, particles = [], raf = 0;
  const pointer = {x:-1000,y:-1000};
  const countForWidth = () => Math.min(68, Math.max(30, Math.floor(width / 13)));
  function resize() {
    const rect = canvas.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = rect.width; height = rect.height;
    canvas.width = Math.round(width * dpr);
    canvas.height = Math.round(height * dpr);
    ctx.setTransform(dpr,0,0,dpr,0,0);
    particles = Array.from({length:countForWidth()}, () => ({
      x:Math.random()*width, y:Math.random()*height,
      vx:(Math.random()-.5)*.22, vy:(Math.random()-.5)*.22,
      r:Math.random()*1.6+.45, a:Math.random()*.5+.2
    }));
  }
  function draw() {
    ctx.clearRect(0,0,width,height);
    for (let i=0;i<particles.length;i++) {
      const p=particles[i];
      p.x+=p.vx; p.y+=p.vy;
      if(p.x<0||p.x>width)p.vx*=-1;
      if(p.y<0||p.y>height)p.vy*=-1;
      const dx=p.x-pointer.x,dy=p.y-pointer.y,dist=Math.hypot(dx,dy);
      if(dist<95){p.x+=dx/(dist||1)*.35;p.y+=dy/(dist||1)*.35;}
      ctx.beginPath();ctx.arc(p.x,p.y,p.r,0,Math.PI*2);
      ctx.fillStyle=`rgba(222,202,255,${p.a})`;ctx.fill();
      for(let j=i+1;j<particles.length;j++){
        const q=particles[j],d=Math.hypot(p.x-q.x,p.y-q.y);
        if(d<105){
          ctx.beginPath();ctx.moveTo(p.x,p.y);ctx.lineTo(q.x,q.y);
          ctx.strokeStyle=`rgba(190,151,246,${(1-d/105)*.15})`;ctx.lineWidth=.7;ctx.stroke();
        }
      }
    }
    raf=requestAnimationFrame(draw);
  }
  canvas.addEventListener("pointermove",e=>{
    const r=canvas.getBoundingClientRect();pointer.x=e.clientX-r.left;pointer.y=e.clientY-r.top;
  },{passive:true});
  canvas.addEventListener("pointerleave",()=>{pointer.x=-1000;pointer.y=-1000;});
  window.addEventListener("resize",resize,{passive:true});
  resize();draw();
  document.addEventListener("visibilitychange",()=>{if(document.hidden)cancelAnimationFrame(raf);else draw();});
})();

// Number keys 1–6 switch sections when the user is not typing.
document.addEventListener("keydown", event => {
  if (event.altKey || event.ctrlKey || event.metaKey) return;
  if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName || "")) return;
  const tabs = ["home","about","creator","development","projects","community","contact"];
  const index = Number(event.key) - 1;
  if (index >= 0 && index < tabs.length) activateTab(tabs[index]);
});


// Creator biography: expandable principles.
document.querySelectorAll(".principle-item").forEach(item => {
  item.addEventListener("click", () => {
    const willOpen = !item.classList.contains("active");
    document.querySelectorAll(".principle-item").forEach(other => {
      other.classList.remove("active");
      other.setAttribute("aria-expanded","false");
    });
    if (willOpen) {
      item.classList.add("active");
      item.setAttribute("aria-expanded","true");
    }
  });
});

// Interactive journey chapters.
const journeyCopy = [
  ["CHAPTER 01","Every creator starts somewhere. Mine is a continued curiosity about building things and discovering what I can make next."],
  ["CHAPTER 02","Experimenting with Roblox Studio, scripting, interfaces, web design, and other creative tools helps turn curiosity into practical skills."],
  ["CHAPTER 03","NOSTYLISTT gives the work a shared identity: a Roblox community, a place to showcase experiences, and a platform for future collaboration."],
  ["CHAPTER 04","The next chapter is open. There are more systems to learn, more projects to explore, and more opportunities to make something better."]
];
document.querySelectorAll(".journey-stop").forEach(stop => {
  stop.addEventListener("click", () => {
    document.querySelectorAll(".journey-stop").forEach(s => s.classList.remove("active"));
    stop.classList.add("active");
    const [chapter, copy] = journeyCopy[Number(stop.dataset.journey)] || journeyCopy[0];
    const detail = document.querySelector(".journey-detail");
    detail.querySelector("span").textContent = chapter;
    detail.querySelector("p").textContent = copy;
    detail.animate?.([{opacity:.35,transform:"translateY(8px)"},{opacity:1,transform:"translateY(0)"}],{duration:350,easing:"ease-out"});
  });
});

// Animate biography statistics only when their section enters view.
const creatorStats = document.querySelector("#creator-stats");
let statsAnimated = false;
function animateCreatorStats() {
  if (!creatorStats || statsAnimated) return;
  const rect = creatorStats.getBoundingClientRect();
  if (rect.top > window.innerHeight * .9 || rect.bottom < 0) return;
  statsAnimated = true;
  creatorStats.querySelectorAll("[data-count]").forEach(el => {
    const target = Number(el.dataset.count);
    const format = el.dataset.format;
    const suffix = el.dataset.suffix || "";
    const start = performance.now();
    const duration = 1500;
    function tick(now) {
      const t = Math.min(1,(now-start)/duration);
      const eased = 1-Math.pow(1-t,4);
      const value = Math.round(target*eased);
      let shown = value.toLocaleString();
      if (format === "compact" && value >= 1000) shown = `${(value/1000).toFixed(value < 10000 || target < 100000 ? 1 : 0)}K`;
      if (format === "comma") shown = value.toLocaleString();
      el.textContent = shown + (t===1 ? suffix : "");
      if (t<1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  });
}
window.addEventListener("scroll",animateCreatorStats,{passive:true});
document.querySelector('[data-tab="creator"]')?.addEventListener("click",()=>setTimeout(animateCreatorStats,250));
if (location.hash === "#creator") setTimeout(animateCreatorStats,300);
